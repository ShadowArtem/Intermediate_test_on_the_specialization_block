package ToyStore.Terminal.Interface;

public interface CommandExecutable {
    void execute();
}