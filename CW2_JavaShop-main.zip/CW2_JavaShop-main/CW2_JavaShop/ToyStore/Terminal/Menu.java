package ToyStore.Terminal;

public class Menu {
    private static String MENU = "Для получения справки по командам введите 'Help'.";

    public static String getMENU() {
        return MENU;
    }
}